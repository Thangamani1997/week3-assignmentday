package week3Assignment;

public abstract class MySqlConnection implements DatabaseConnection 
{
	public void executeQuery() 
	{
		// TODO Auto-generated method stub
		System.out.println("Query Executed Sucessfully");

	}
}
