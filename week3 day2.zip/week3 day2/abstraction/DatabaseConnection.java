package week3Assignment;

public interface DatabaseConnection
{
	public void connect();
	
	public void disconnect();
	
	public void executeUpdated();
}
