package week3Assignment;

public class TextField extends WebElement
{
	public void gettex() 
	{
		// TODO Auto-generated method stub
		String name = "Thangamani";
		System.out.println("GET TEXT METHOD");
		System.out.println("Enter The Name - "+name);
	}
}
