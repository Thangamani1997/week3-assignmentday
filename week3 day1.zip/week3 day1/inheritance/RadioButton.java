package week3Assignment;

public class RadioButton extends Button
{
	public void selectRadioButton() 
	{
		// TODO Auto-generated method stub
		System.out.println("SELECT RADIO BUTTON METHOD");
		System.out.println("Radio Button is selected");
	}
}
