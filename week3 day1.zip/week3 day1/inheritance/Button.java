package week3Assignment;

public class Button extends WebElement
{
	public void submit() 
	{
		// TODO Auto-generated method stub
		System.out.println("SUBMIT METHOD");
		System.out.println("Click The submit Button to Submit you data");
	}
}
