package week3Assignment;

public class WebElement
{
	public void click() 
	{
		// TODO Auto-generated method stub
		System.out.println("CLICK METHOD");
		System.out.println("Click The Button to open the webpage");
	}
	
	public void setText(String text) 
	{
		// TODO Auto-generated method stub
		System.out.println("SET TEXT METHOD");
		System.out.println("Set of Text = "+text);
	}
	
	
	
	
}
