package week3Assignment;

public class CheckboxButton extends Button
{
	public void clickCheckButton() 
	{
	// TODO Auto-generated method stub
		System.out.println("CLICK CHECKBOX BUTTON METHOD");
		System.out.println("CheckBox Button is Clicked");
	} 
}
