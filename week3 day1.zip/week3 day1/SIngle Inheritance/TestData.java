package week3Assignment;

public class TestData 
{

	public void enterCredential() 
	{
		// TODO Auto-generated method stub
		System.out.println("Enter Credentials");
	}
	
	public void navigateToHomePage()
	{
		// TODO Auto-generated method stub
		System.out.println("Navigate to Home Page to know more details");
	}
	

}
